import os
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from collections import defaultdict

TOKEN = os.getenv("BOT_TOKEN")

users_rizz = defaultdict(int)
relationships = {}

LANGUAGES = {
    "ru": {"start": "Привет, я Риззард 🤖", "rizz": "Ты подкатил и получил {points}🔥"},
    "en": {"start": "Hey, I'm Rizzard 🤖", "rizz": "You rizzed and got {points}🔥"},
    "kk": {"start": "Сәлем, мен Риззард 🤖", "rizz": "Сен подкат жасап, {points}🔥 алдың"},
    "zh": {"start": "你好，我是Rizzard 🤖", "rizz": "你撩了一下，获得了 {points}🔥"},
    "es": {"start": "Hola, soy Rizzard 🤖", "rizz": "Has rizzado y conseguiste {points}🔥"}
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = "ru"
    await update.message.reply_text(LANGUAGES[lang]["start"])

async def rizz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    users_rizz[user.id] += 1
    points = users_rizz[user.id]
    lang = "ru"
    await update.message.reply_text(LANGUAGES[lang]["rizz"].format(points=points))

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    points = users_rizz.get(user.id, 0)
    await update.message.reply_text(f"🔥 У тебя {points} очков ризза")

async def breakup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id in relationships:
        partner = relationships.pop(user.id)
        relationships.pop(partner, None)
        await update.message.reply_text("💔 Вы расстались!")
    else:
        await update.message.reply_text("У тебя нет отношений 😢")

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("rizz", rizz))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("breakup", breakup))
    app.run_polling()

if __name__ == "__main__":
    main()
